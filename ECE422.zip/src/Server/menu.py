menu = """Commands:
user_create <username> <password>
activate_user <username> |ADMIN ONLY|
delete_user <username> |ADMIN ONLY|
user_list_requests |ADMIN ONLY|
whoami
login <username> <password>
logout delete a user (
menu
group_create <groupname>
group_add <username> <groupname>
group_remove <username> <groupname>
group_list
create <filename / path>
delete <filename>
read <filename>
write <local filename>
rename <filename> <new filename>
chmod <3 perm numbers (0,1,2,3)> <filename>
cd <path>
mkdir <directory name>
ls
pwd"""